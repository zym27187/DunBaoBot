![](https://i.loli.net/2021/04/19/Lyhaf1leKg9VZ6J.png)
# 今天吃什么

（懒得仔细写readme了，反正没人看）

foods文件夹置于res/img目录下

指令：今天/早上/中午/晚上/夜宵+吃+什么/啥
例子：今天吃什么

欢迎提交PR丰富美食列表

参考json文件增加即可，图片以jpg格式放置在foods文件夹中